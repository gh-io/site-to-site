#define MT_VERSION "8.00"
#define GIT_HASH "unknown"
